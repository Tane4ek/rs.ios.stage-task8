//
//  SubView.h
//  RSSchool_T8
//
//  Created by Татьяна Лузанова on 17.07.2021.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SubView : UIView

- (instancetype) initWithFrame:(CGRect)frame andColor:(UIColor *)color;

@end

NS_ASSUME_NONNULL_END
