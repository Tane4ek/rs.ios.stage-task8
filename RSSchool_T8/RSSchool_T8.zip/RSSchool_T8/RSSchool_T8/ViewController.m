//
//  ViewController.m
//  RSSchool_T8
//
//  Created by Татьяна Лузанова on 16.07.2021.
//

#import "ViewController.h"
#import "SubView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UINavigationItem *NavigatonBar;
//@property(nonatomic, readwrite, strong, nullable) UIBarButtonItem *rightBarButtonItem;

@property (weak, nonatomic) IBOutlet UIView *image;
@property (weak, nonatomic) IBOutlet UIButton *openPalette;
@property (weak, nonatomic) IBOutlet UIButton *openTimer;
@property (weak, nonatomic) IBOutlet UIButton *draw;
@property (weak, nonatomic) IBOutlet UIButton *share;

@property (nonatomic, strong) SubView *paletteView;
//@property (nonatomic, strong) RSView *yellowView;


@property UIColor *imageColor;

@property UIColor *textBottomColor;
@property UIColor *red;
@property UIColor *blue;
@property UIColor *green;
@property UIColor *gray;
@property UIColor *purple;
@property UIColor *peach;
@property UIColor *yellow;
@property UIColor *lightBlue;
@property UIColor *pink;
@property UIColor *black;
@property UIColor *darkGray;
@property UIColor *vine;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    setupColors
    self.imageColor = [UIColor colorWithRed:0.0/255 green:178.0/255 blue:255.0/255 alpha:1];
    self.textBottomColor = [UIColor colorWithRed:33.0/255 green:176.0/255 blue:142.0/255 alpha:1];
    self.red = [UIColor colorWithRed:226.0/255 green:27.0/255 blue:44.0/255 alpha:1];
    self.blue = [UIColor colorWithRed:62.0/255 green:23.0/255 blue:204.0/255 alpha:1];
    self.green = [UIColor colorWithRed:0.0/255 green:124.0/255 blue:55.0/255 alpha:1];
    self.gray = [UIColor colorWithRed:128.0/255 green:128.0/255 blue:128.0/255 alpha:1];
    self.purple = [UIColor colorWithRed:157.0/255 green:94.0/255 blue:234.0/255 alpha:1];
    self.peach = [UIColor colorWithRed:255.0/255 green:122.0/255 blue:104.0/255 alpha:1];
    self.yellow = [UIColor colorWithRed:255.0/255 green:173.0/255 blue:84.0/255 alpha:1];
    self.lightBlue = [UIColor colorWithRed:0.0/255 green:174.0/255 blue:237.0/255 alpha:1];
    self.pink = [UIColor colorWithRed:255.0/255 green:119.0/255 blue:162.0/255 alpha:1];
    self.black = [UIColor colorWithRed:0.0/255 green:46.0/255 blue:60.0/255 alpha:1];
    self.darkGray = [UIColor colorWithRed:14.0/255 green:55.0/255 blue:24.0/255 alpha:1];
    self.vine = [UIColor colorWithRed:97.0/255 green:15.0/255 blue:16.0/255 alpha:1];
    
//    setup imageView
    self.image.layer.cornerRadius = 8;
    self.image.layer.shadowColor = self.imageColor.CGColor;
    self.image.layer.shadowRadius = 8;
    self.image.layer.shadowOffset = CGSizeMake(0, 0);
    self.image.layer.shadowOpacity = 0.25;
    
    
//    setup button
    [self.openPalette setTitle:@"Open Palette" forState:UIControlStateNormal];
    self.openPalette.layer.cornerRadius = 10;
    self.openPalette.layer.borderColor = UIColor.lightGrayColor.CGColor;
    self.openPalette.layer.borderWidth = 2;

    [self.openTimer setTitle:@"Open Timer" forState:UIControlStateNormal];
    self.openTimer.layer.cornerRadius = 10;
    self.openTimer.layer.borderColor = UIColor.lightGrayColor.CGColor;
    self.openTimer.layer.borderWidth = 2;
    
    [self.draw setTitle:@"Draw" forState:UIControlStateNormal];
    self.draw.layer.cornerRadius = 10;
    self.draw.layer.borderColor = UIColor.lightGrayColor.CGColor;
    self.draw.layer.borderWidth = 2;
    
    [self.share setTitle:@"Share" forState:UIControlStateNormal];
    self.share.layer.cornerRadius = 10;
    self.share.layer.borderColor = UIColor.lightGrayColor.CGColor;
    self.share.layer.borderWidth = 2;
    self.share.alpha = 0.5;
    self.share.enabled = NO;
    
//    setupPaletteColors
    self.paletteView = [[SubView alloc] initWithFrame:CGRectMake(0, 333, 375, 333.5) andColor:[UIColor whiteColor]];
    [self.view addSubview:self.paletteView];
    self.paletteView.hidden = YES;
    
//  Adding SaveColorsButton

    UIButton *saveColorButton = [[UIButton alloc] initWithFrame:CGRectMake(250, 20, 85, 32)];
    [saveColorButton setTitle:@"Save" forState:UIControlStateNormal];
    [self.paletteView addSubview:saveColorButton];
    saveColorButton.layer.cornerRadius = 10;
    saveColorButton.layer.borderColor = UIColor.lightGrayColor.CGColor;
    [saveColorButton setTitleColor:self.textBottomColor forState:UIControlStateNormal];
    saveColorButton.layer.borderWidth = 2;
   
    
        [saveColorButton addTarget:self
                            action:@selector(tapSave:)
                            forControlEvents:UIControlEventTouchUpInside];


    
//    secureButton action
    [self.openPalette addTarget:self
                              action:@selector(openPaletteTapped:)
                              forControlEvents:UIControlEventTouchUpInside];
}

-(void)openPaletteTapped: (UIButton *)sender {
    self.paletteView.hidden = NO;
}

-(void)tapSave: (UIButton *)sender {
    self.paletteView.hidden = YES;
}

@end
