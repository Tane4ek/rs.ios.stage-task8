//
//  SceneDelegate.h
//  RSSchool_T8
//
//  Created by Татьяна Лузанова on 16.07.2021.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

